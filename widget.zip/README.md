Widget for THE OTHER
